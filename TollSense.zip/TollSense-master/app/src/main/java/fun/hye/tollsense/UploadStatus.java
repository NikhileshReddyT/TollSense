package fun.hye.tollsense;

/**
 * Created by sceint on 6/25/17.
 */

public interface UploadStatus {
    void getDBStatus(String message);
}
